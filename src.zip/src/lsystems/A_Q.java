package lsystems;

public class A_Q extends LRule{
	public char getMatch() {
		return 'A';
	}
	
	public char[] getBody() {
		char[] array = new char[] {'Q'};
		return array;
	}
}
