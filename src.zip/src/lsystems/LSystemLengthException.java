package lsystems;

public class LSystemLengthException extends Exception{
	private char noChar;
	   
	public LSystemLengthException(char noChar) {
      this.noChar = noChar;
    }
}
