package lsystems;

import java.util.List;
import java.util.Set;

public class LLine {
	char line[];
	Set<LRule> rules;
	
	public LLine (char[] start, Set<LRule> rules) {
		this.rules = rules;
		this.line = start;
	}
	
	public void process() throws LSystemSymbolException, LSystemLengthException {
		LRule r1 = new A_A();
		LRule r2 = new A_AA();
		LRule r3 = new A_BC();
		LRule r4 = new B_A();
		LRule r5 = new C_B();
		LRule r6 = new A_Q();
		LRule r7 = new A_X();
		
		for (int i = 0; i <= line.length; i++) {
			if (r1.getMatch() == 'A') {
				line = r1.getBody();
			}
		}
	
		for (int i = 0; i <= line.length; i++) {
			if (r2.getMatch() == 'A') {
				line = r2.getBody();
			}
		}
		
		for (int i = 0; i <= line.length; i++) {
			if (r3.getMatch() == 'A') {
				line = r3.getBody();
			}
		}
		
		for (int i = 0; i <= line.length; i++) {
			if (r4.getMatch() == 'B') {
				line = r4.getBody();
			}
		}
		
		for (int i = 0; i <= line.length; i++) {
			if (r5.getMatch() == 'C') {
				line = r5.getBody();
			}
		}
		
		for (int i = 0; i <= line.length; i++) {
			if (r6.getMatch() == 'A') {
				line = r6.getBody();
			}
		}
		
		for (int i = 0; i <= line.length; i++) {
			if (r7.getMatch() == 'A') {
				line = r7.getBody();
			}
		}
	}
	
	private char[] listToArray(List<Character> list) {
		char[] newChars = new char[list.size()];
		for (int i = 0; i < list.size(); i++) {
			newChars[i] = list.get(i);
		}
		return newChars;
	}

	public String toString() {
		return new String(line);
	}
}
