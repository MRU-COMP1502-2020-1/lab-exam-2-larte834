package lsystems;

public class A_A extends LRule{
	public char getMatch() {
		return 'A';
	}
	
	public char[] getBody() {
		char[] array = new char[] {'A'};
		return array;
	}
}
